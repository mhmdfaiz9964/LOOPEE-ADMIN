function shortEmail(email, mask = "**********") {
    return email;
} 

function shortNumber(countryCode,phoneNumber) {   
    return countryCode + phoneNumber;
}

function shortEditNumber(phoneNumber){
    return phoneNumber;
}

function shortReportNumber(countryCode,phoneNumber){
    return countryCode + phoneNumber;
}

function EditPhoneNumber(phoneNumber) {
    return phoneNumber;
}